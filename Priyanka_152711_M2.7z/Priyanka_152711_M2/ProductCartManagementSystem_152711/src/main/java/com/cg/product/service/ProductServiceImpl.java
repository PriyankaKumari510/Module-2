package com.cg.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dto.ProductCart;
import com.cg.product.repo.IProductRepo;
@Service
public class ProductServiceImpl implements IProductService{

	@Autowired
	IProductRepo repo;
	
	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<getAllProducts>
	 - Input Parameters	:	<Product> <String>
	 - Return Type		:	<list> 
	 - Author			:	<Priyanka>
	 - Creation Date    :	08/08/2018
	 - Description		:	Getting All product details
	 ********************************************************************************************************/

	@Override
	public List<ProductCart> getAllProduct() {
		List<ProductCart> list=new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}
	
	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<getProdcutById>
	 - Input Parameters	:	<Id> <String>
	 - Return Type		:	<void> 
	 - Author			:	<Priyanka>
	 - Creation Date    :	08/08/2018
	 - Description		:	Getting one product details
	 ********************************************************************************************************/
	@Override
	public Optional<ProductCart> getProductById(String id) {
		return repo.findById(id);
	}
	
	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<Addproduct>
	 - Input Parameters	:	<Product> <String>
	 - Return Type		:	<void> 
	 - Author			:	<Priyanka>
	 - Creation Date	:	08/08/2018
	 - Description		:	product is added
	 ********************************************************************************************************/
	@Override
	public void addProduct(ProductCart product) {
		repo.save(product);
		
	}
	
	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<Updateproduct>
	 - Input Parameters	:	<id> <String>
	 - Return Type		:	<void> 
	 - Author			:	<Priyanka>
	 - Creation Date   :	08/08/2018
	 - Description		:	product is updated
	 ********************************************************************************************************/
	@Override
	public void updateProduct(ProductCart product, String id) {
		repo.save(product);	
		
	}
	
	//------------------------    <Productcart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<Deleteproducts>
	 - Input Parameters	:	<id> <String>
	 - Return Type		:	<void> 
	 - Author			:	<Priyanka>
	 - Creation Date	:	08/08/2018
	 - Description		:	product is deleted
	 ********************************************************************************************************/
	@Override
	public void deleteProduct(String id) {
		repo.deleteById(id);
	}
	
}
