package com.cg.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.ProductCart;
import com.cg.product.service.IProductService;

@RestController
public class ProductController {
	
	@Autowired
	private IProductService service;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public void addProduct(@RequestBody ProductCart product) {
		service.addProduct(product);

	}
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public void updateProduct(@RequestBody ProductCart product, @PathVariable String id) {
		service.updateProduct(product, id);
		}
	
	@RequestMapping(value = "/delete/{id}", method=RequestMethod.DELETE)
	public void deleteProduct(@PathVariable String id) {
		service.deleteProduct(id);
	}
	
	@RequestMapping("/products")
	public List<ProductCart> showProduct() {
		return service.getAllProduct();
	}

	@RequestMapping("/products/{id}")
	public Optional<ProductCart> getProductById(@PathVariable String id) {
		return service.getProductById(id);
	}
}
