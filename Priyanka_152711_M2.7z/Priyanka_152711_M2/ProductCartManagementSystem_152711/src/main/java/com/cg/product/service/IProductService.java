package com.cg.product.service;

import java.util.List;
import java.util.Optional;
import com.cg.product.dto.ProductCart;

public interface IProductService {
	
	public List<ProductCart> getAllProduct();

	public Optional<ProductCart> getProductById(String id);

	public void addProduct(ProductCart product);

	public void updateProduct(ProductCart product, String id);

	public void deleteProduct(String id);

}
