package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.product")
public class ProductCartManagementSystem152711Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementSystem152711Application.class, args);
	}
}
