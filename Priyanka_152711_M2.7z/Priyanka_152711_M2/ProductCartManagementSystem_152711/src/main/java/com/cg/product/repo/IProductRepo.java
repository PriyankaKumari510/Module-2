package com.cg.product.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cg.product.dto.ProductCart;

@Repository("productrepo")
public interface IProductRepo extends CrudRepository<ProductCart, String>{

}
